AeroPlan run export

Run ID: 47b10bd460d3
Results and all 1,800 series (when the full dataset is used) belong to this run only.
Cost values use source cost units; currency is unspecified.
Immediate fill counts only current demand filled on arrival.
Selected policies and configuration were saved before evaluation in frozen.json.
source.zip contains the executable Python source captured at run start.
inputs.zip contains the raw CSV bytes and import mappings in provenance.json.
To reproduce: extract source.zip, install requirements.txt, then run
python tools/replay_export.py <path-to-this-export.zip> --output replay.json
The fixed test period has previously been examined; subsequent tuning is exploratory.
